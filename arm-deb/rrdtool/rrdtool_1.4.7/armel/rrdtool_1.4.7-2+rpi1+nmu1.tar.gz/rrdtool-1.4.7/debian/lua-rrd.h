#ifndef LUA_RRD_H
#define LUA_RRD_H

extern int luaopen_rrd (lua_State * L);

#endif
